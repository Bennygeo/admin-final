export const environment = {
  production: true,
  firbase: {
    apiKey: "AIzaSyCJuJIg5p2YTsY8EdUrm9AgtcI9rqTGb0Q",
    authDomain: "thinkspot-e4cc9.firebaseapp.com",
    databaseURL: "https://thinkspot-e4cc9.firebaseio.com",
    projectId: "thinkspot-e4cc9",
    storageBucket: "thinkspot-e4cc9.appspot.com",
    messagingSenderId: "614482375695"
  },
  url: "http://www.thinkspot.in/php/"
  // url:"http://www.lifiadesign.com/php/"
};