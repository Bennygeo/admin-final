import { ArrayUtils } from './array-utils';

describe('ArrayUtils', () => {
  it('should create an instance', () => {
    expect(new ArrayUtils()).toBeTruthy();
  });
});
