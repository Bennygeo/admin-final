import { ScrollToTopDirective } from './scroll-to-top.directive';

describe('ScrollToTopDirective', () => {
  it('should create an instance', () => {
    const directive = new ScrollToTopDirective();
    expect(directive).toBeTruthy();
  });
});
